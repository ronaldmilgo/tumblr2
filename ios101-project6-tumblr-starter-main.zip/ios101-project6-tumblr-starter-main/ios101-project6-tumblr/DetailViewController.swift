//
//  DetailViewController.swift
//  ios101-project6-tumblr
//

import UIKit
import Nuke

class DetailViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var captionTextView: UITextView!

    // This will be set from the main feed when a post is selected
    var post: Post?

    override func viewDidLoad() {
        super.viewDidLoad()

        if let post = post {
            captionTextView.text = post.caption.trimHTMLTags()
            if let photo = post.photos.first {
                Nuke.loadImage(with: photo.originalSize.url, into: imageView)
            }
        }

        // Disable text editing in the captionTextView
        captionTextView.isEditable = false
    }
}
